/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

/**
 *
 * @author slaya
 */
public class TimeGenerator {
 int openTime; //Time, in minutes, when the store opens
 int openHour; //Hour the store opens
 int closeHour; //Hour the store closes
 int closeTime; //Time, in minutes, when the store closes
 double[] hourFreArray; //Will contain percentages for every second of the day of how likely someone is to come in during that time
 double[] minuteFreArray;
 double[] freArray;
 
 public TimeGenerator(int openTime, int closeTime){//For 6am - 12am, the values are 21600 and 86400
     this.openTime = openTime;
     this.closeTime = closeTime;
     freArray = new double[closeTime-openTime];
     populateArray();
 }
 
 public void populateArray(){
     double [] newHourFre = makeArray();
     for(int i = 0, j = openHour, pos = 0; j != closeHour; i++, j++){
        for(int k = 0; k!=60; k++){
           freArray[pos] = newHourFre[i]/60;
           pos++;
        }
     }
     
//     double total = 0;
//     for(int i = 0; i != freArray.length; i++){
//         total += freArray[i];
//         //System.out.print(i + "= "+ freArray[i] + ", ");
//     }
//     System.out.println("Total: " + total);
 }
 
 public double[] makeArray(){
     double[] hourFre = new double[]{.0075, .003, .001, .0005, .0005, .001, .01, .015, .025, .05, .06, .065, .075, .075, .077, .11, .1, .105, .075, .06, .045,  .02, .012, .0075}; 
     //=1.0                         [12,  1,   2,    3,     4,     5,    6,   7,    8,    9,  10,  11,  12,13/1,14/2,15/3,16/4, 17/5,18/6,19/7, 20/8, 21/9,22/10,23/11]
     int totalHours = (closeTime-openTime)/60;
     openHour = openTime/60;
     closeHour = closeTime/60;
     double fraction = 0;
     for(int i = openHour; i != closeHour; i++){
       fraction+=hourFre[i];
     }
     double multiplier = 1D/fraction;
     double [] newHourFre = new double[closeHour - openHour];
     for(int i = openHour, j = 0; i != closeHour; i++, j++){
     newHourFre[j] = multiplier * hourFre[i];
     }
     return newHourFre;
 }
 
 public int getArrivalTime(){
    int minute = openTime;
    double total = 0;
    double rando = Math.random();
    while(rando >= total){
        total += freArray[minute - openTime];
        minute++;
    }
   // System.out.println(minute);
    return minute;
 }
}
