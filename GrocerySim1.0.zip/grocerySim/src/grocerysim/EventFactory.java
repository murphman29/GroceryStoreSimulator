/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.util.ArrayList;

/**
 *
 * @author slaya
 */

//Creates at least 2 events for each and every customer. The first is an arrivalEvent, which can be followed by either the StarbucksArrival, DeliArrival, or CheckoutArrival events.
public class EventFactory {
    RNG rng;
    public static RNG staticRNG;
    public EventFactory(){
    rng = new RNG();
    staticRNG = new RNG();
    }
    
    public void makeEvents(ArrayList<Customer> customers){
        for(int i = 0; i!=customers.size(); i++){
        Customer theCustomer = customers.get(i);
        makeArrivalEvent(theCustomer);
        }
    }
    public static void makeEventAfterArrival(Customer theCustomer){
        makeStarbucksEvent(theCustomer);
        makeDeliEvent(theCustomer);
        makeCheckoutArrivalEvent(theCustomer);
    }
        
   public void makeArrivalEvent(Customer c){
    ArrivalEvent ae = new ArrivalEvent(c.getEnterTime(), c.getID());
    EventQueue.push(ae);
   }
   
    public static void makeDeliEvent(Customer c){//Creates a Deli Event if.f the customer does not visit starbucks
    if(c.getDeli() && !c.getStarbucks()){
     DeliArrival dw = new DeliArrival(c.getEnterTime() + staticRNG.Random(15), c.getID());//Assumes that a customer would visit the deli within 15 mintues of arrival
     EventQueue.push(dw);    
    }
   }
    
    public static void makeStarbucksEvent(Customer c){
     if(c.getStarbucks()){
     StarbucksArrival se = new StarbucksArrival(c.getEnterTime() + staticRNG.Random(10), c.getID());//Assumes that customers would get coffee within the first 10 minutes of arriving if they are going to
     EventQueue.push(se);
     }
   }
    
    public static void makeCheckoutArrivalEvent(Customer c){
     if(!c.getDeli() && !c.getStarbucks()){//Makes this event if.f the customer does not visit the deli or starbucks
      CheckoutArrival ca = new CheckoutArrival(c.getEnterTime() + staticRNG.Random(7, 90), c.getID());
      EventQueue.push(ca);
     }
    }
    
}
