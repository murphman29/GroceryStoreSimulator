/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.PriorityQueue;

/**
 *
 * @author Jared Murphy
 */
public class GrocerySim {

    CustomerFactory cf;
    EventFactory eg;
    PriorityQueue pq;

    /**
     * @param args the command line arguments
     */

    //This Class will be soley for the generation of our event queues and processing
    public static void main(String[] args) {
        
        /**What-If Questions to be answered:
         * What if more cashiers were available to help check people out?
         * What if the weather was amazing one day, and many more customers came in than expected? how would waiting times be impacted?
         */
        
        /**Explanation of function calls:
         * CustomerFactory: (starLike,deliLike, weatherQuality, averageCustomers, openTime, closeTime) 
         *      starLike = percent chance that a customer will go to Starbucks
         *      deliLike = percent chance that a customer will go to the deli
         *      weatherQuality = how 'good' the weather is. .5 = average, .5 < above average, .5 > below average
         *      averageCustomers = how many customers come into the store as a year-round average
         *      weatherWeight = weight, between 0 and 1, that weather affects how many people go shopping
         *      openTime = time, in minutes, of when the store opens. (i.e. 360 = 6am)
         *      closeTime = time, in minutes, of when the store closes. (i.e. 1440 = 12am)
         * EventQueue(customerList, cashiers, backupCashiers, deliWorkers, starbucksWorkers)
         *      customerList = Generated from a CustomerFactory. Is a collection of all customers for the current day and when they will arrive based on a PMF generated from an actual Walmart 
         *      cashiers = number of cashiers that will ALWAYS be on a register
         *      backupCashiers = number of people who can run register that can be called to assist the front end
         *      deliWorkers = number of deliWorkers who can serve customers
         *      starbucksWorkers = number of starbucksWorkers who can serve customers
         */     
        
        //This is where you can set all of the day/store-affected vairables listed above, if you so desire.
        double starLike = .15;
        double deliLike = .1;
        double weatherQuality = .5;
        int averageCustomers = 3000;
        double weatherWeight = .2;
        int openTime = 360;
        int closeTime = 1440;
        
        //These are your independent variables. Change them to affect the simulation.
        int cashiers = 3;
        int backupCashiers = 2;
        int deliWorkers = 1;
        int starbucksWorkers = 1;
        
        //Here we go!
        simulate(starLike, deliLike, weatherQuality, averageCustomers, weatherWeight, openTime, closeTime, cashiers, backupCashiers, deliWorkers, starbucksWorkers);
    }
        
        
        
        public static void simulate(double starLike, double deliLike, double weatherQuality, int averageCustomers, double weatherWeight, int openTime, int closeTime, int cashiers,int backupCashiers, int deliWorkers, int starbucksWorkers){
        CustomerFactory cf = new CustomerFactory(starLike, deliLike, weatherQuality, averageCustomers, weatherWeight, openTime, closeTime);
        EventQueue eq = new EventQueue(cf.generateCustomers(), cashiers, backupCashiers, deliWorkers, starbucksWorkers); 
        ArrayList<Event> eventsCompleted = new ArrayList<Event>();
        //EQ generates the arrivalEvent, a checkoutEvent, and any warranted deliVisit or starbucksVisit events
        //It is assumed that there is a standard distribution around a total trip length of 42 mintues per http://timeuseinstitute.org/Grocery%20White%20Paper%202008.pdf
        int count = 0;
        try {
            while (!eq.isEmpty()) {
                count++;
                Event event = eq.pop();
                event.process();
                eventsCompleted.add(event);
            }
        } catch (Exception e) {
            System.out.println(count);
        }
       writeResultsToFile(eventsCompleted, printStats(eq.getMaster()));
    }
        
        
    public static void writeResultsToFile(ArrayList<Event> events, String recap){
        try{
    File file = new File("results.txt");
    if(file.exists()){
        file.delete();
        file.createNewFile();
    }
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(recap);
    bw.flush();
    for(int i = 0; i != events.size(); i++){
    bw.write(events.get(i).toString());
    bw.flush();
    }
    bw.close();
    }catch(Exception e){
        System.out.println("Oops");
    }
    }


    public static String printStats(int[] master) {
        int deliCount = 0;
        int starbucksCount = 0;
        int deliWaited = 0;
        int starWaited = 0;
        int checkoutWaited = 0;
        int checkoutCustomersWaited = 0;
        int maxCheckoutWait = 0;
        for(int i = 0; i != EventQueue.getCustomerSize(); i++){
            Customer c = EventQueue.getCustomer(i);
            if(c.getDeli()){
                deliCount++;
                deliWaited += c.getDeliWait();
            }
            if(c.getStarbucks()){
                starbucksCount++;
                starWaited += c.getStarWait();
            }
            if(c.getCheckoutWait() > maxCheckoutWait){
                maxCheckoutWait = c.getCheckoutWait();
            }
            checkoutWaited += c.getCheckoutWait();
            
            if(c.getCheckoutWait() != 0){
                checkoutCustomersWaited++;
            }
        }
        
        String output = "";
        System.out.println("Customers: " + EventQueue.getCustomerSize() + "\n\t Average wait to checkout: " + (checkoutWaited/EventQueue.getCustomerSize()) + " seconds \n\t Average wait to checkout(Excluding those who didn't have to wait): " + (checkoutWaited/checkoutCustomersWaited) + " seconds \n\t Number of callup occurrences: " + EventQueue.getCallups() + "\n\t Maximum Checkout Wait Time: " + maxCheckoutWait + " seconds");
        System.out.println("Deli Visits: " + deliCount + "\n\t Average Wait: " + (deliWaited/deliCount) + " seconds");
        System.out.println("Starbs Visits: " + starbucksCount + "\n\t Average Wait: " + (starWaited/starbucksCount) + " seconds");
        System.out.println("///////////////////////////////////////////////////////////////");
        output += ("Customers: " + EventQueue.getCustomerSize() + "\n\t Average wait to checkout: " + (checkoutWaited/EventQueue.getCustomerSize()) + " seconds \n\t Average wait to checkout(Excluding those who didn't have to wait): " + (checkoutWaited/checkoutCustomersWaited) + " seconds \n\t Number of callup occurrences: " + EventQueue.getCallups() + "\n\t Maximum Checkout Wait Time: " + maxCheckoutWait + " seconds\n");
        output += ("Deli Visits: " + deliCount + "\n\t Average Wait: " + (deliWaited/deliCount) + " seconds\n");
        output += ("Starbs Visits: " + starbucksCount + "\n\t Average Wait: " + (starWaited/starbucksCount) + " seconds\n");
        output += ("///////////////////////////////////////////////////////////////\n");
        return output;
    }
    
    public static void printEventLog(int[]master){
        System.out.println("\nArrivals: " + master[0]);
        System.out.println("Deli Arrivals: " + master[2]);
        System.out.println("Deli Waits: " + master[1]);
        System.out.println("Starbucks Arrivals: " + master[4]);
        System.out.println("Starbucks Waits: " + master[3]);
        System.out.println("Checkout Arrivals: " + master[5]);
        System.out.println("Checkout Waits: " + master[6]);
        System.out.println("...Departures: " + master[8]);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
    public static void printVisitDistribution(){
        int[] hours = new int[24];
        for(int i = 0; i!= EventQueue.getCustomerSize(); i++){
         hours[(EventQueue.getCustomer(i).getEnterTime()-60)/60]++;
        }
        System.out.println("Distribution of visits by hour");
        displayArray(hours);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
     public static void printHourVisitDistribution(){
        int[] hours = new int[60];
        for(int i = 0; i!= EventQueue.getCustomerSize(); i++){
         hours[EventQueue.getCustomer(i).getEnterTime()%60]++;
        }
        System.out.println("Distribution of visits by minute across all hours");
        displayArray(hours);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
     public static void displayArray(int[] myArray){ //Prints out an array of integers
           float sum = 0;
           if(myArray.length < 1){
            return;
           }
           String output = "";
           output += "[";
           for(int i = 0; i!= myArray.length; i++){
               output+=myArray[i] + ", ";
               sum += myArray[i];
           }           
           System.out.println(output.substring(0, output.length()-2) + "]");
           System.out.println("Sum: " + sum);
       }

}
