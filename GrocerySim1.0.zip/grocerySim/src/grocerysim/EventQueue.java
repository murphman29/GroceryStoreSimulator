/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.util.ArrayList;
import java.util.PriorityQueue;

/**
 *
 * @author slaya
 */
public class EventQueue {

    private static PriorityQueue<Event> queue;
    private static ArrayList<Customer> customerList;
    private static int clock;
    private static int deliWorkers;
    private static int starbucksWorkers;
    private static int cashiers;
    private static int reliefCashiers;
    private static int leaveEvents;
    private static int size;
    private static int callups;
    private static int[] eventFreq = new int[9];
    private static int[] masterFreq = new int[9];

    public EventQueue(ArrayList<Customer> customerList, int cashiers, int reliefCashiers, int deliWorkers, int starbucksWorkers) {
        this.customerList = customerList;
        queue = new PriorityQueue<Event>();
        EventFactory ef = new EventFactory();
        this.deliWorkers = deliWorkers;
        this.starbucksWorkers = starbucksWorkers;
        this.cashiers = cashiers;
        this.reliefCashiers = reliefCashiers;
        this.callups = 0;
        this.leaveEvents = 0;
        this.size = 0;
        clock = 0;
        ef.makeEvents(customerList);
    }

    public EventQueue() {
        EventFactory ef = new EventFactory();
        clock = 0;
    }

    public static void push(Event e) {
        size++;
        eventFreq[e.getEventCode()]++;
        masterFreq[e.getEventCode()]++;
        if (!queue.offer(e)) {
            Exception ex = new Exception("The queue has rejected your input at size " + queue.size());
            ex.printStackTrace();
        };
    }

    public static Event pop() {
        size--;
        Event re = queue.poll();
        eventFreq[re.getEventCode()]--;
        clock = re.getEndTime();
        if (re.getEventCode() == 8) {
            leaveEvents++;
        }
        return re;
    }

    public static Event peek() {
        return queue.peek();
    }

    public boolean isEmpty() {
        if (queue.size() <= 0) {
            return true;
        } else {
            return false;
        }
    }

    public static int size() {
        return size;
    }

    public static Customer getCustomer(int pos) {
        return customerList.get(pos);
    }

    public static int getCustomerSize() {
        return customerList.size();
    }

    public static int getEvents(int type) {
        if (type >= 0 && type < 9) {
            return eventFreq[type];
        } else {
            return 0;
        }
    }

    public static int getDeliWorkers() {
        return deliWorkers;
    }

    public static int getStarbucksWorkers() {
        return starbucksWorkers;
    }

    public static int getCashiers() {
        return cashiers;
    }

    public static int getShoppers() {
        return customerList.size() - getEvents(0) - masterFreq[8];
    }

    public static int[] getMaster() {
        return masterFreq;
    }

    public static int requestBackup(int requested) {
        if (requested < reliefCashiers) {
            callups += requested;
            return requested;
        } else {
            return reliefCashiers;
        }
    }
    
    public static int getCallups(){
        return callups;
    }

}
