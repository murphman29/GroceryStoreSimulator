/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

/**
 * EventCode Dictionary:
 * 0 = Arrival
 * 1 = DeliWaiting
 * 2 = DeliArrival
 * 3 = StarbucksWaiting
 * 4 = StarbucksArrival
 * 5 = CheckoutArrival
 * 6 = CheckoutWaiting
 * 7 = Checkout
 * 8 = Leaving
 * 
 * @author slaya
 */
public class Event implements Comparable{
int eventCode;
int startTime;
int endTime;
int customerID;
public Event(int eventCode, int endTime, int customerID){
this.eventCode = eventCode;
this.endTime = endTime;
this.customerID = customerID;
}

public int getEventCode(){
    return eventCode;
}

public int getEndTime(){
   return endTime;
}

public void process(){
    return;
}

@Override
public int compareTo(Object o) {
Event x = (Event)o;
if(this.endTime > x.endTime){
    return 1;
}else if(this.endTime == x.endTime){
    return 0;
}else{
    return -1;
}
}   

@Override
public String toString(){
    return eventCode + "\t" + endTime + "\t" + customerID + "\n";
}
}

//EC 0
class ArrivalEvent extends Event{
    public ArrivalEvent(int endTime, int customerID){
        super(0, endTime, customerID);
    }
    
    @Override
    public void process(){
    EventFactory.makeEventAfterArrival(EventQueue.getCustomer(customerID));
    }
}

//EC 1
class DeliWaiting extends Event{
    public DeliWaiting(int endTime, int customerID) {
        super(1, endTime, customerID);
    }
    
    @Override
    public void process(){
    //The only other event for them is the checkout event, so create one
    RNG rng = new RNG();
    CheckoutArrival ca = new CheckoutArrival(endTime + rng.Random(5, 40), customerID);
    EventQueue.push(ca);
    }
}
//EC 2
 class DeliArrival extends Event{
    public DeliArrival(int endTime, int customerID) {
        super(2, endTime, customerID);
    }
    
    @Override
    public void process(){
        RNG rng = new RNG();
    int serveTime =endTime + (rng.Random(1,4) * (EventQueue.getEvents(1) / EventQueue.getDeliWorkers())); 
    //Each customer is assumed to take between 1 and 4 minutes to be helped, and they will wait depending on the following algorithm:
    //LineArrivalTime + RANDOM(1-4) * (NumberOfCustomersWaiting / numberOfWorkers)
    EventQueue.push( new DeliWaiting(serveTime, customerID));
    EventQueue.getCustomer(customerID).setDeliWait(serveTime-endTime);
    }
}
//EC 3
class StarbucksWaiting extends Event{
    public StarbucksWaiting(int endTime, int customerID) {
        super(3, endTime, customerID);
    }
    
    @Override
    public void process(){
     if(EventQueue.getCustomer(customerID).getDeli()){//If the customer still needs to visit the deli, make a deli Arrival event 
         RNG rng = new RNG();
         DeliArrival da = new DeliArrival(endTime + rng.Random(10), customerID);//Assumes that the deliArrival will be roughly 10 minutes after receiving their SBs
         EventQueue.push(da);
     }else{//Otherwise, create a checkoutArrival event because that's the next event they'll go to
         RNG rng = new RNG();
         CheckoutArrival ca = new CheckoutArrival(endTime + rng.Random(5, 40), customerID);
         EventQueue.push(ca);
     }
    }
}
//EC 4
class StarbucksArrival extends Event{
    public StarbucksArrival(int endTime, int customerID) {
        super(4, endTime, customerID);
    }
    
     @Override
    public void process(){
        RNG rng = new RNG();
        double lineDepth = EventQueue.getEvents(3)/EventQueue.getStarbucksWorkers();
        double random = rng.Random(50.00,250.00);
        int waitInSeconds = (int) (random * lineDepth);
        int wait = (int)((random/60.00) * lineDepth);
    int serveTime = endTime + wait;
    if(wait < 0){
       serveTime = endTime;
    }
    //Each customer is assumed to take between 15 seconds and 4 minutes to be helped, and they will wait depending on the following algorithm:
    //LineArrivalTime + RANDOM(50sec-200sec) * (NumberOfCustomersWaiting / numberOfWorkers)
    EventQueue.push( new StarbucksWaiting(serveTime, customerID));
    EventQueue.getCustomer(customerID).setStarWait(waitInSeconds);
    }
}

//EC 5
class CheckoutArrival extends Event{
    public CheckoutArrival(int endTime, int customerID) {
        super(5, endTime, customerID);
    }
    
     @Override
    public void process(){
        RNG rng = new RNG();
        double lineDepth = EventQueue.getEvents(6)/EventQueue.getCashiers();
        if(lineDepth > 2){
         lineDepth = EventQueue.getEvents(6)/(EventQueue.getCashiers()+EventQueue.requestBackup((int) (lineDepth - 2)));
        }
        double random = rng.Random(30.00,300.00);
        int waitInSeconds = (int) (random * lineDepth);
        int wait = (int)((random/60.00) * lineDepth);
    int serveTime = endTime + wait;
    if(wait < 0){
       serveTime = endTime;
    }
    //Each customer is assumed to take between 15 seconds and 4 minutes to be helped, and they will wait depending on the following algorithm:
    //LineArrivalTime + RANDOM(50sec-200sec) * (NumberOfCustomersWaiting / numberOfWorkers)
    EventQueue.push( new CheckoutWaiting(serveTime, customerID));
    EventQueue.getCustomer(customerID).setCheckoutWait((waitInSeconds));
    }
}
//EC 6
class CheckoutWaiting extends Event{
    public CheckoutWaiting(int endTime, int customerID) {
        super(6, endTime, customerID);
    }
    
    @Override
    public void process(){
        RNG rng = new RNG();
        LeaveEvent le = new LeaveEvent(endTime + rng.Random(4), customerID);
        EventQueue.push(le);
    }
}
//EC 7
class Checkout extends Event{
    public Checkout(int endTime, int customerID) {
        super(7, endTime, customerID);
    }
}
//EC 8
class LeaveEvent extends Event{
    public LeaveEvent(int endTime, int customerID) {
        super(8, endTime, customerID);
    }
    
    public void processEvent(){
    EventQueue.getCustomer(customerID).setExitTime(endTime);
    }

}
