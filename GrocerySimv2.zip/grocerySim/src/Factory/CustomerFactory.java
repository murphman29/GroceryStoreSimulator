/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package Factory;

import java.util.ArrayList;
import Generators.*;
import grocerysim.*;

/**
 *
 * @author slaya
 */
//Although this sounds a little gruesome, it is completely humane
//StarbucksLikely: This can be an integer from 0-3. This variable will be used to determine
//whether or not a customer will get Starbucks during their trip and how many drinks they may get.
//0 = No Drink, 1 = 30% chance, 2 = 60% chance , 3 = 90%
//The distribution of these will be done so that the mean percentage of people who get starbucks will end up being 15% total
//DeliLikely: Same case as StarbucksLikely, however the expected total deli customers should be 20% of the total Customers
public class CustomerFactory {
    TimeGenerator tg;
    visitGenerator sb; //StarBucks
    visitGenerator deli;//Deli
    double weatherQuality; //How desirable, on a scale of .0->1, the weather is
    double weatherWeight; //How much, on a scale of .0 -> 1, weather affects customer count. (0 is the least, 1 is entirely. If it is 1, nobody is coming in the winter)
    int averageCustomers;
public CustomerFactory(double SCP, double DCP, double WQ, int AC, double weatherWeight, int openTime, int closeTime){ //NOTE: times must be in minutes
    tg = new TimeGenerator(openTime, closeTime);
    sb = new visitGenerator(SCP);
    deli = new visitGenerator(DCP);
    this.weatherQuality = WQ;
    this.averageCustomers = AC;
    this.weatherWeight = weatherWeight;
}
/*
    //Tested with new CustomerFactory(.15,.2, .5,3000, .2);, which produced 3000 as desired
    //CustomerFactory(.15,.2, 1,3000, .2);, which produced 3600 as desired
    //CustomerFactory(.15,.2, 0,3000, .2);, which produced 2400 as desired
*/
public ArrayList<Customer> generateCustomers(){  
    
 int toGenerate = (int) (((1-weatherWeight)* averageCustomers) + (2 * weatherWeight * weatherQuality * averageCustomers));
 ArrayList <Customer> returnList = new ArrayList<Customer>();
 for(int i = 0; i != toGenerate; i ++){
     returnList.add(new Customer(i, deli.willVisit(), sb.willVisit(), tg.getArrivalTime() ));//ID, Deli, Starbucks, Entry Time
 }
 return returnList;
}

}
