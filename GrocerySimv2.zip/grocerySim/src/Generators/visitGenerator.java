/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Generators;

/**
 *
 * @author slaya
 */
public class visitGenerator {//Takes in a target value and creates an outcome generator that will return either a true or false
    //This is intended for use by the Starbucks and Deli portion
    private double target;
    boolean [] distribution;
    public visitGenerator(double target){
        this.target = target;
        makeDistribution();
    }
    private void makeDistribution(){
    distribution = new boolean[100];
    int newTarget = (int)(target*100);
    for(int i = 0; i != 100; i++){
        if(i <= newTarget){
           distribution[i] = true; 
        }else{
            distribution[i] = false;
        }
    }
    }
    
    public boolean willVisit(){
    int index = (int)(Math.random() * 100);
    return distribution[index];
    }
    
    /**
     * Tested using:
     visitGenerator vg = new visitGenerator(.2);
     int yes = 0;
      int no = 0;
     for(int i = 0; i != 100; i++){
      if(vg.willVisit()){
          yes ++;
      }else{
          no++;
      }      
     }
     System.out.println("Yes: " + yes + "No: " + no);
    }
     */
}
