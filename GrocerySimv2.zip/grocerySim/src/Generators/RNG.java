/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Generators;

import java.util.Random;

/**
 *
 * @author slaya
 */
public class RNG {
public RNG(){
 
}

public int Random(int max){//Assumes minimum is 0
int rv = -1;
while(rv < 0 || rv > max){
    rv = (int) Math.random()*100;
}
return rv;
 
}
public double Random(double max){//Assumes minimum is 0
double rv = -1;
while(rv < 0 || rv > max){
    rv = Math.random()*100;
}
return rv;
 
}
public int Random(int min, int max){
int rv = -1;
while(true){
    if(rv < min || rv > max){
    rv = (int) (Math.random()*100);
    }else{
        return rv;
    }
}
}
public double Random(double min, double max){//Assumes minimum is 0
double rv = -1;
while(rv < min || rv > max){
    rv = (Math.random()*100);
}
return rv;
 
}

public double RandomNormal(double min, double max){
double range = max - min;
Random r = new Random();
double rv = 0;
while(true){
double number = r.nextGaussian();
rv = number * max;
if((rv > min) && (rv < max)){
  return rv;
}
}
}

}
