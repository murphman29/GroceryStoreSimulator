/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 8
public class LeaveEvent extends Event{
    public LeaveEvent(int endTime, int customerID) {
        super(8, endTime, customerID);
    }
    
    public void processEvent(){
    EventQueue.getCustomer(customerID).setExitTime(endTime);
    }

}
