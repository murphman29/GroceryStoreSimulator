/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 1
public class DeliWaiting extends Event{
    public DeliWaiting(int endTime, int customerID) {
        super(1, endTime, customerID);
    }
    
    @Override
    public void process(){
    //The only other event for them is the checkout event, so create one
    RNG rng = new RNG();
    CheckoutArrival ca = new CheckoutArrival(endTime + rng.Random(5, 40), customerID);
    EventQueue.push(ca);
    }
}
