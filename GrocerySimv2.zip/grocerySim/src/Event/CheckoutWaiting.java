/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 6
public class CheckoutWaiting extends Event{
    public CheckoutWaiting(int endTime, int customerID) {
        super(6, endTime, customerID);
    }
    
    @Override
    public void process(){
        RNG rng = new RNG();
        EventQueue.exitLine(EventQueue.getCustomer(customerID).getLineChosen());
        LeaveEvent le = new LeaveEvent(endTime + rng.Random(4), customerID);
        EventQueue.push(le);
    }
}
