/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;
import Generators.*;
import Factory.*;

/**
 * EventCode Dictionary:
 * 0 = Arrival
 * 1 = DeliWaiting
 * 2 = DeliArrival
 * 3 = StarbucksWaiting
 * 4 = StarbucksArrival
 * 5 = CheckoutArrival
 * 6 = CheckoutWaiting
 * 7 = Checkout
 * 8 = Leaving
 * 
 * @author slaya
 */
public class Event implements Comparable{
protected int eventCode;
protected int startTime;
protected int endTime;
protected int customerID;
public Event(int eventCode, int endTime, int customerID){
this.eventCode = eventCode;
this.endTime = endTime;
this.customerID = customerID;
}

public int getEventCode(){
    return eventCode;
}

public int getEndTime(){
   return endTime;
}

public void process(){
    return;
}

@Override
public int compareTo(Object o) {
Event x = (Event)o;
if(this.endTime > x.endTime){
    return 1;
}else if(this.endTime == x.endTime){
    return 0;
}else{
    return -1;
}
}   

@Override
public String toString(){
    return endTime + "\t" + eventCode + "\t" + customerID + "\n";
}
}







