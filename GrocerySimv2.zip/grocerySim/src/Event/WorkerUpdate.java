/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
public class WorkerUpdate extends Event{
    int cashiers;
    int reliefCashiers;
    int deliWorkers;
    int starbucksWorkers;
    public WorkerUpdate(int endTime, int cashiers, int reliefCashiers, int deliWorkers, int starbucksWorkers) {
        super(7, endTime, 9999);
        this.cashiers = cashiers;
        this.reliefCashiers = reliefCashiers;
        this.deliWorkers = deliWorkers;
        this.starbucksWorkers = starbucksWorkers;
    }
    
    @Override
    public void process(){
    EventQueue.setCashiers(cashiers);
    EventQueue.setBackupCashiers(reliefCashiers);
    EventQueue.setDeliWorkers(deliWorkers);
    EventQueue.setStarbucksWorkers(starbucksWorkers);
    }
    
    @Override
    public String toString(){
     return super.toString() + "WORKERS WERE CHANGED HERE"; 
    }
    
}
