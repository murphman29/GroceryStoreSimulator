/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.*;

/**
 *
 * @author slaya
 */
//EC 5
public class CheckoutArrival extends Event {
    int serveTime = 0;

    public CheckoutArrival(int endTime, int customerID) {
        super(5, endTime, customerID);
    }

    @Override
    public void process() {
        RNG rng = new RNG();
        double lineDepth = EventQueue.getEvents(6) / EventQueue.getCashiers();
        if (lineDepth > 2) {
            lineDepth = EventQueue.getEvents(6) / (EventQueue.getCashiers() + EventQueue.requestBackup((int) (lineDepth - 2)));
        }
        double random = rng.RandomNormal(EventQueue.getMinimumCheckoutTime(), EventQueue.getMaximumCheckoutTime());
//        int waitInSeconds = (int) (random * lineDepth);
//        int wait = (int) ((random / 60.00) * lineDepth);
//        int serveTime = endTime + wait;
//        if (wait < 0) {
//            serveTime = endTime;
//        }
        //Each customer is assumed to take between 15 seconds and 4 minutes to be helped, and they will wait depending on the following algorithm:
        //LineArrivalTime + RANDOM(50sec-200sec) * (NumberOfCustomersWaiting / numberOfWorkers)
        //EventQueue.push(new CheckoutWaiting(serveTime, customerID));
        int serveTime = 0;
        Customer c= EventQueue.getCustomer(customerID);
        c.setCheckoutTime((int) Math.round(random/60));
        c.setLineChosen(EventQueue.enterLine(c));//Determines which line the customer goes in
        c.setCheckoutWait(EventQueue.getLineTime(c.getLineChosen()));
        serveTime = (c.getCheckoutTime() + c.getCheckoutWait()) + endTime;
        //System.out.print(c.getCheckoutWait() + ", ");
        EventQueue.push(new CheckoutWaiting(serveTime, customerID));    
        this.serveTime = serveTime;
        
    }
    
    @Override 
    public String toString(){
        return endTime + "\t" + eventCode + "\t" + customerID + "\tCustomer should have a checkout event at " + serveTime + "\n";
    }
}
