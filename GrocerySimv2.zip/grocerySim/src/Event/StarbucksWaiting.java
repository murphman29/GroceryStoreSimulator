/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 3
public class StarbucksWaiting extends Event{
    public StarbucksWaiting(int endTime, int customerID) {
        super(3, endTime, customerID);
    }
    
    @Override
    public void process(){
     if(EventQueue.getCustomer(customerID).getDeli()){//If the customer still needs to visit the deli, make a deli Arrival event 
         RNG rng = new RNG();
         DeliArrival da = new DeliArrival(endTime + rng.Random(10), customerID);//Assumes that the deliArrival will be roughly 10 minutes after receiving their SBs
         EventQueue.push(da);
     }else{//Otherwise, create a checkoutArrival event because that's the next event they'll go to
         RNG rng = new RNG();
         CheckoutArrival ca = new CheckoutArrival(endTime + rng.Random(5, 40), customerID);
         EventQueue.push(ca);
     }
    }
}
