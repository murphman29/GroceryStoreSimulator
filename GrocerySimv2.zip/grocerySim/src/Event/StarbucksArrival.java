/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 4
public class StarbucksArrival extends Event{
    public StarbucksArrival(int endTime, int customerID) {
        super(4, endTime, customerID);
    }
    
     @Override
    public void process(){
        RNG rng = new RNG();
        double lineDepth = EventQueue.getEvents(3)/EventQueue.getStarbucksWorkers();
        double random = rng.Random(50.00,250.00);
        int waitInSeconds = (int) (random * lineDepth);
        int wait = (int)((random/60.00) * lineDepth);
    int serveTime = endTime + wait;
    if(wait < 0){
       serveTime = endTime;
    }
    //Each customer is assumed to take between 15 seconds and 4 minutes to be helped, and they will wait depending on the following algorithm:
    //LineArrivalTime + RANDOM(50sec-200sec) * (NumberOfCustomersWaiting / numberOfWorkers)
    EventQueue.push( new StarbucksWaiting(serveTime, customerID));
    EventQueue.getCustomer(customerID).setStarWait(waitInSeconds);
    }
}
