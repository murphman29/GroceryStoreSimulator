/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Generators.RNG;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 2
 public class DeliArrival extends Event{
    public DeliArrival(int endTime, int customerID) {
        super(2, endTime, customerID);
    }
    
    @Override
    public void process(){
        RNG rng = new RNG();
    int serveTime =endTime + (rng.Random(1,4) * (EventQueue.getEvents(1) / EventQueue.getDeliWorkers())); 
    //Each customer is assumed to take between 1 and 4 minutes to be helped, and they will wait depending on the following algorithm:
    //LineArrivalTime + RANDOM(1-4) * (NumberOfCustomersWaiting / numberOfWorkers)
    EventQueue.push( new DeliWaiting(serveTime, customerID));
    EventQueue.getCustomer(customerID).setDeliWait(serveTime-endTime);
    }
}
