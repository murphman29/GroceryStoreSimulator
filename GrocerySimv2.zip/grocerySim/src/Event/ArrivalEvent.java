/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Event;

import Factory.EventFactory;
import grocerysim.EventQueue;

/**
 *
 * @author slaya
 */
//EC 0
public class ArrivalEvent extends Event{
    public ArrivalEvent(int endTime, int customerID){
        super(0, endTime, customerID);
    }
    
    @Override
    public void process(){
    EventFactory.makeEventAfterArrival(EventQueue.getCustomer(customerID));
    }
}
