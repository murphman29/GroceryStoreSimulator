/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.Writer;
import java.util.ArrayList;
import java.util.PriorityQueue;
import Factory.*;
import Event.*;

/**
 *
 * @author Jared Murphy
 */
public class GrocerySim {

    CustomerFactory cf;
    EventFactory eg;
    PriorityQueue pq;

    /**
     * @param args the command line arguments
     */

    //This Class will be soley for the generation of our event queues and processing
    public static void main(String[] args) {
        
        /**What-If Questions to be answered:
         * What if more cashiers were available to help check people out?
         * What if the weather was amazing one day, and many more customers came in than expected? how would waiting times be impacted?
         */
        
        /**Explanation of function calls:
         * CustomerFactory: (starLike,deliLike, weatherQuality, averageCustomers, openTime, closeTime) 
         *      starLike = percent chance that a customer will go to Starbucks
         *      deliLike = percent chance that a customer will go to the deli
         *      weatherQuality = how 'good' the weather is. .5 = average, .5 < above average, .5 > below average
         *      averageCustomers = how many customers come into the store as a year-round average
         *      weatherWeight = weight, between 0 and 1, that weather affects how many people go shopping
         *      openTime = time, in minutes, of when the store opens. (i.e. 360 = 6am)
         *      closeTime = time, in minutes, of when the store closes. (i.e. 1440 = 12am)
         * EventQueue(customerList, cashiers, backupCashiers, deliWorkers, starbucksWorkers)
         *      customerList = Generated from a CustomerFactory. Is a collection of all customers for the current day and when they will arrive based on a PMF generated from an actual Walmart 
         *      cashiers = number of cashiers that will ALWAYS be on a register
         *      backupCashiers = number of people who can run register that can be called to assist the front end
         *      deliWorkers = number of deliWorkers who can serve customers
         *      starbucksWorkers = number of starbucksWorkers who can serve customers
         *      cashRegisters = number of cash registers that exist within the store's checkout area (not peripheal ones, like at the deli or floral shop)
         */     
        
        //This is where you can set all of the day/store-affected parameters listed above, if you so desire.
        double starLike = .15;
        double deliLike = .1;
        double weatherQuality = .5;
        int averageCustomers = 3000;
        double weatherWeight = .2;
        int openTime = 360;
        int closeTime = 1440;
        
        //These can be altered using WorkerUpdates.
        //These are your independent variables, or parameters. Change them to affect the simulation.
        int cashiers = 6;
        //WARNING: Include self checkout amount. For this case, it is 6
        int backupCashiers = 2;
        int deliWorkers = 1;
        int starbucksWorkers = 1;
        int cashRegisters = 15;
        double minimumCheckoutTime = 94.00;
        double maximumCheckoutTime = 300.00;
        
        //Update the following events to change the workforce throughout the day
         ArrayList<Event> updates = new ArrayList<Event>();
        updates.add(new WorkerUpdate(420, 7, 4, 1, 1)); //7am
        updates.add( new WorkerUpdate(540, 8, 4, 1, 1)); //9am
        updates.add( new WorkerUpdate(660, 9, 4, 1, 1)); //11am
        updates.add(new WorkerUpdate(720, 10, 4, 1, 1)); //12am
        updates.add( new WorkerUpdate(840, 11, 3, 1, 1)); //2pm
        updates.add(new WorkerUpdate(960, 11, 4, 1, 1)); //4pm
        updates.add(new WorkerUpdate(1200, 11, 1, 1, 1)); //8pm
        updates.add( new WorkerUpdate(1260, 7, 1, 1, 1)); //9pm
        updates.add( new WorkerUpdate(1320, 6, 0, 1, 1)); //10pm
        
        //Here we go!
        simulate(starLike, deliLike, weatherQuality, averageCustomers, weatherWeight, openTime, closeTime, cashiers, backupCashiers, deliWorkers, starbucksWorkers, cashRegisters, minimumCheckoutTime, maximumCheckoutTime, updates);
    }
        
        
        
        public static void simulate(double starLike, double deliLike, double weatherQuality, int averageCustomers, double weatherWeight, int openTime, int closeTime, int cashiers,int backupCashiers, int deliWorkers, int starbucksWorkers, int cashRegisters, double minimumCheckoutTime, double maximumCheckoutTime, ArrayList<Event> updates){
        CustomerFactory cf = new CustomerFactory(starLike, deliLike, weatherQuality, averageCustomers, weatherWeight, openTime, closeTime);
        EventQueue eq = new EventQueue(cf.generateCustomers(), cashiers, backupCashiers, deliWorkers, starbucksWorkers, cashRegisters, minimumCheckoutTime, maximumCheckoutTime);
        for(int i = 0; i != updates.size(); i++){
           EventQueue.push(updates.get(i));
        }
        ArrayList<Event> eventsCompleted = new ArrayList<Event>();
        //EQ generates the arrivalEvent, a checkoutEvent, and any warranted deliVisit or starbucksVisit events
        //It is assumed that there is a standard distribution around a total trip length of 42 mintues per http://timeuseinstitute.org/Grocery%20White%20Paper%202008.pdf
        int count = 0;
        try {
            while (!eq.isEmpty()) {
                count++;
                Event event = eq.pop();
                event.process();
                eventsCompleted.add(event);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println(count);
        }
        System.out.println(count);
       writeResultsToFile(eventsCompleted, printStats(eq.getMaster()));
    }
        
        
    public static void writeResultsToFile(ArrayList<Event> events, String recap){
        try{
    File file = new File("results.txt");
    if(file.exists()){
        file.delete();
        file.createNewFile();
    }else{
        file.createNewFile();
    }
    BufferedWriter bw = new BufferedWriter(new FileWriter(file));
    bw.write(recap);
    bw.flush();
    for(int i = 0; i != events.size(); i++){
    bw.write(events.get(i).toString());
    bw.flush();
    }
    bw.close();
    }catch(Exception e){
        e.printStackTrace();
        System.out.println("Oops");
    }
    }


    public static String printStats(int[] master) {
        int deliCount = 0;
        int starbucksCount = 0;
        int deliWaited = 0;
        int starWaited = 0;
        int checkoutWaited = 0;
        int checkoutCustomersWaited = 0;
        int maxCheckoutWait = 0;
        int maxDeliWait = 0;
        int maxStarbucksWait = 0; 
        for(int i = 0; i != EventQueue.getCustomerSize(); i++){
            Customer c = EventQueue.getCustomer(i);
            if(c.getDeli()){
                if(c.getDeliWait() > maxDeliWait){
                maxDeliWait = c.getDeliWait();
            }
                deliCount++;
                deliWaited += c.getDeliWait();
            }
            if(c.getStarbucks()){
                if(c.getStarWait() > maxStarbucksWait){
                maxStarbucksWait = c.getStarWait();
            }
                starbucksCount++;
                starWaited += c.getStarWait();
            }
            if(c.getCheckoutWait() > maxCheckoutWait){
                maxCheckoutWait = c.getCheckoutWait();
            }
            checkoutWaited += c.getCheckoutWait();
            
            if(c.getCheckoutWait() != 0){
                checkoutCustomersWaited++;
            }
        }
        
        String output = "";
        System.out.println("Customers: " + EventQueue.getCustomerSize() + "\n\t Average wait to checkout: " + (checkoutWaited/EventQueue.getCustomerSize()) + " minutes \n\t Average wait to checkout(Excluding those who didn't have to wait): " + (checkoutWaited/checkoutCustomersWaited) + " minutes \n\t Number of callup occurrences: " + EventQueue.getCallups() + "\n\t Number of orders administered by callups: " + EventQueue.getCallupOrders() + "\n\t Maximum Checkout Wait Time: " + maxCheckoutWait + " minutes");
        System.out.print("\t Cash Register Checkout Distribution: ");
        System.out.println(displayArray(EventQueue.getRegisterRecord()));
        System.out.println("Deli Visits: " + deliCount + "\n\t Average Wait: " + (deliWaited/deliCount) + " seconds\n\t Max Deli Wait: " + maxDeliWait + " seconds");
        System.out.println("Starbs Visits: " + starbucksCount + "\n\t Average Wait: " + (starWaited/starbucksCount) + " seconds\n\t Max Starbucks Wait: " + maxStarbucksWait + " seconds");
        System.out.println("///////////////////////////////////////////////////////////////");
        output += ("Customers: " + EventQueue.getCustomerSize() + "\n\t Average wait to checkout: " + (checkoutWaited/EventQueue.getCustomerSize()) + " seconds, or " + 
                ((int)(checkoutWaited/EventQueue.getCustomerSize())/60) + ":" + ((int)(checkoutWaited/EventQueue.getCustomerSize())%60) + " minutes \n\t Average wait to checkout(Excluding those who didn't have to wait): " + (checkoutWaited/checkoutCustomersWaited) + " seconds \n\t Number of callup occurrences: " + EventQueue.getCallups() + "\n\t Number of orders administered by callups: " + EventQueue.getCallupOrders() + "\n\t Maximum Checkout Wait Time: " + maxCheckoutWait + " seconds");
        output += "\t Cash Register Checkout Distribution: ";
        output += displayArray(EventQueue.getRegisterRecord());
        output += ("Deli Visits: " + deliCount + "\n\t Average Wait: " + (deliWaited/deliCount) + " seconds\n\t Max Deli Wait: " + maxDeliWait + " seconds");
        output += ("Starbs Visits: " + starbucksCount + "\n\t Average Wait: " + (starWaited/starbucksCount) + " seconds\n\t Max Starbucks Wait: " + maxStarbucksWait + " seconds");
        output += ("///////////////////////////////////////////////////////////////");
        return output;
    }
    
    public static void printEventLog(int[]master){
        System.out.println("\nArrivals: " + master[0]);
        System.out.println("Deli Arrivals: " + master[2]);
        System.out.println("Deli Waits: " + master[1]);
        System.out.println("Starbucks Arrivals: " + master[4]);
        System.out.println("Starbucks Waits: " + master[3]);
        System.out.println("Checkout Arrivals: " + master[5]);
        System.out.println("Checkout Waits: " + master[6]);
        System.out.println("...Departures: " + master[8]);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
    public static void printVisitDistribution(){
        int[] hours = new int[24];
        for(int i = 0; i!= EventQueue.getCustomerSize(); i++){
         hours[(EventQueue.getCustomer(i).getEnterTime()-60)/60]++;
        }
        System.out.println("Distribution of visits by hour");
        displayArray(hours);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
     public static void printHourVisitDistribution(){
        int[] hours = new int[60];
        for(int i = 0; i!= EventQueue.getCustomerSize(); i++){
         hours[EventQueue.getCustomer(i).getEnterTime()%60]++;
        }
        System.out.println("Distribution of visits by minute across all hours");
        displayArray(hours);
        System.out.println("///////////////////////////////////////////////////////////////");
    }
    
     public static String displayArray(int[] myArray){ //Prints out an array of integers
           float sum = 0;
           if(myArray.length < 1){
            return "";
           }
           String output = "";
           output += "[";
           for(int i = 0; i!= myArray.length; i++){
               output+=myArray[i] + ", ";
               sum += myArray[i];
           }           
           //System.out.println(output.substring(0, output.length()-2) + "]");
           return output.substring(0, output.length()-2) + "]";
           //System.out.println("Sum: " + sum);
       }

}
