/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.util.Date;

/**
 *
 * @author slaya
 */
public class Customer {

    private int id;
    private boolean visitDeli;
    private boolean visitStarbucks;
    private int enterTime;
    private int exitTime;
    private int checkoutTime;
    private int durationInMinutes;
    private int deliWait;
    private int starWait;
    private int checkoutWait;
    private int lineChosen;

    public Customer(int id, boolean visitDeli, boolean visitStarbucks, int enterTime) {
        this.id = id;
        this.visitDeli = visitDeli;
        this.visitStarbucks = visitStarbucks;
        this.enterTime = enterTime;
        this.durationInMinutes = 0;
        this.deliWait = 0;
        this.starWait = 0;
    }

    public void setExitTime(int minute) {
        this.exitTime = minute;
        this.durationInMinutes = exitTime - enterTime;
    }

    public void increaseExitTime(int increase) {
        setExitTime(exitTime + increase);
    }

    public int getDuration() {
        return durationInMinutes;
    }

    public boolean getDeli() {
        return visitDeli;
    }

    public void setDeliWait(int wait) {
        this.deliWait = wait;
    }

    public void setStarWait(int wait) {
        this.starWait = wait;
    }
    
    public void setCheckoutWait(int wait){
        this.checkoutWait = wait;
    }
    
    public int getCheckoutTime(){
        return checkoutTime;
    }
    
    public void setCheckoutTime(int time){
        this.checkoutTime = time;
    }
    
    public int getCheckoutWait(){
        return checkoutWait;
    }

    public int getDeliWait() {
        return deliWait;
    }

    public int getStarWait() {
        return starWait;
    }
    
    public int getLineChosen(){
        return lineChosen;
    }
    
    public void setLineChosen(int line){
        lineChosen = line;
    }

    public boolean getStarbucks() {
        return visitStarbucks;
    }

    public int getEnterTime() {
        return enterTime;
    }

    public int getID() {
        return id;
    }
}
