/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package grocerysim;

import java.util.ArrayList;
import java.util.PriorityQueue;
import Factory.*;
import Event.*;
import java.util.Queue;

/**
 *
 * @author slaya
 */
public class EventQueue {

    private static PriorityQueue<Event> queue;
    private static ArrayList<Customer> customerList;
    private static int clock;
    private static double minimumCheckoutTime;
    private static double maximumCheckoutTime;
    private static int deliWorkers;
    private static int starbucksWorkers;
    private static int cashiers;
    private static int reliefCashiers;
    private static int leaveEvents;
    private static int size;
    private static int callups;
    private static int callupOrdersCompleted;
    private static ArrayList<Customer> [] registerQueue;
    private static int[] registerRecord;
    private static int[] eventFreq = new int[9];
    private static int[] masterFreq = new int[9];

    public EventQueue(ArrayList<Customer> customerList, int cashiers, int reliefCashiers, int deliWorkers, int starbucksWorkers, int cashRegisters, double mict, double mact) {
        this.customerList = customerList;
        queue = new PriorityQueue<Event>();
        EventFactory ef = new EventFactory();
        this.deliWorkers = deliWorkers;
        this.starbucksWorkers = starbucksWorkers;
        this.cashiers = cashiers;
        this.reliefCashiers = reliefCashiers;
        this.callups = 0;
        this.leaveEvents = 0;
        this.size = 0;
        this.maximumCheckoutTime = mact;
        this.minimumCheckoutTime = mict;
        this.callupOrdersCompleted = 0;
        this.registerQueue = new ArrayList[cashRegisters];
        for(int i = 0; i != cashRegisters; i++){
            registerQueue[i] = new ArrayList<Customer>();
        }
        this.registerRecord = new int[cashRegisters];
        clock = 0;
        ef.makeEvents(customerList);
    }

    public EventQueue() {
        EventFactory ef = new EventFactory();
        clock = 0;
    }

    public static void push(Event e) {
        size++;
        eventFreq[e.getEventCode()]++;
        masterFreq[e.getEventCode()]++;
        if (!queue.offer(e)) {
            Exception ex = new Exception("The queue has rejected your input at size " + queue.size());
            ex.printStackTrace();
        };
    }

    public static Event pop() {
        try{
        size--;
        Event re = queue.poll();
        eventFreq[re.getEventCode()]--;
        clock = re.getEndTime();
        if (re.getEventCode() == 8) {
            leaveEvents++;
        }
        return re;
        }catch(Exception e){
            return new Event(10,clock,9998);
        }
    }

    public static Event peek() {
        return queue.peek();
    }

    public boolean isEmpty() {
        if (queue.size() <= 0) {
            return true;
        } else {
            return false;
        }
    }

    public static int size() {
        return size;
    }
    
    public static void setCashiers(int num){
        cashiers = num;
    }
    
    public static void setBackupCashiers(int num){
        reliefCashiers = num;
    }
    
    public static void setDeliWorkers(int num){
        deliWorkers = num;
    }
    
    public static void setStarbucksWorkers(int num){
        starbucksWorkers = num;
    }

    public static Customer getCustomer(int pos) {
        return customerList.get(pos);
    }

    public static int getCustomerSize() {
        return customerList.size();
    }

    public static int getEvents(int type) {
        if (type >= 0 && type < 9) {
            return eventFreq[type];
        } else {
            return 0;
        }
    }

    public static int getDeliWorkers() {
        return deliWorkers;
    }

    public static int getStarbucksWorkers() {
        return starbucksWorkers;
    }

    public static int getCashiers() {
        return cashiers;
    }

    public static int getShoppers() {
        return customerList.size() - getEvents(0) - masterFreq[8];
    }

    public static int[] getMaster() {
        return masterFreq;
    }

    public static int requestBackup(int requested) {
        if (requested < reliefCashiers) {
            return requested;
        } else {
            return reliefCashiers;
        }
    }
    
    public static int getCallups(){
        return callups;
    }
    
    public static int getCallupOrders(){
        return callupOrdersCompleted;
    }
    
    public static int enterLine(Customer c){//Takes in the customer ID that will be entering the line, and returns which line is shortest
    int shortestLength = 100;
    int lineID = 0;
    for(int i = 0; i != cashiers; i++){
    if(registerQueue[i].size() < shortestLength){
        lineID = i;
        shortestLength = registerQueue[i].size();
    }
    }
    if(shortestLength > 2){
        for(int i = cashiers; i != (cashiers + reliefCashiers); i++){
         if(registerQueue[i].size() < 2){
         lineID = i;
         registerQueue[lineID].add(c);
         registerRecord[lineID]++;
         return lineID;
        } else if(registerQueue[i].size() < shortestLength){
            shortestLength = registerQueue[i].size();
            lineID = i;
        }
        }
    }
    registerQueue[lineID].add(c);
    registerRecord[lineID]++;
    return lineID;
    }
    
    public static void exitLine(int lineID){
     registerQueue[lineID].remove(0);
     registerQueue[lineID].trimToSize();
     if(lineID >= cashiers){
       if(registerQueue[lineID].size() == 0){
           callups++;
       }
       callupOrdersCompleted ++;
     }
    }
    
    public static int getLineTime(int lineID){
    int time = 0;
    for(int i = 0; i != registerQueue[lineID].size() - 1; i++){
        time += registerQueue[lineID].get(i).getCheckoutTime();
    }
    return time;
    }
    
    public static int[] getRegisterRecord(){
        return registerRecord;
    }
    
    public static double getMinimumCheckoutTime(){
        return minimumCheckoutTime;
    }
    
    public static double getMaximumCheckoutTime(){
        return maximumCheckoutTime;
    }

}
